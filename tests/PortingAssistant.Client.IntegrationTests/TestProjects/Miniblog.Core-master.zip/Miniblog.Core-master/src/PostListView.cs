namespace Miniblog.Core
{
    public enum PostListView
    {
        TitlesOnly,

        TitlesAndExcerpts,

        FullPosts
    }
}
