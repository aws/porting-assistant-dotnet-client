using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Components;

namespace eShopLegacyWebForms
{
    public partial class Site_Mobile : LayoutComponentBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}